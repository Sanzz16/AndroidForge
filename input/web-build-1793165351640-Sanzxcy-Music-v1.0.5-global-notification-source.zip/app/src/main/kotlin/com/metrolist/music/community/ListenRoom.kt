/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 *
 * Sanzxcy Music: Dengar Bersama. Host membagikan kode/link, tamu otomatis memutar lagu yang sama
 * dan disinkronkan posisi serta status play/pause-nya (polling ringan tiap 2 detik).
 */

package com.metrolist.music.community

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import coil3.compose.AsyncImage
import com.metrolist.innertube.models.WatchEndpoint
import com.metrolist.music.LocalListenTogetherManager
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.listentogether.ConnectionState
import com.metrolist.music.listentogether.ListenTogetherEvent
import com.metrolist.music.playback.queues.YouTubeQueue
import com.metrolist.music.ui.component.glassBorder
import com.metrolist.music.ui.theme.LocalLiquidGlass
import com.sanzxcy.music.com.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Kode ruangan dari link/deep link (sanzxcy://join?code=XXXXXX) menunggu diproses ListenPanel. */
object CommunityDeepLink {
    val pendingCode = MutableStateFlow<String?>(null)
}

private val YT_ID = Regex("^[A-Za-z0-9_-]{11}$")
private val JOIN_BASE: String get() = CommunityApi.baseUrl + "/join/"

class ListenRoomSession {
    val code = mutableStateOf<String?>(null)
    val isHost = mutableStateOf(false)
    val members = mutableIntStateOf(1)
    val hostName = mutableStateOf("")
    val remote = mutableStateOf<ListenState?>(null)
    val joinInput = mutableStateOf("")
}

@Composable
fun ListenRoomSyncEffect(state: CommunityState, roomSession: ListenRoomSession) {
    val token = state.token ?: return
    val lifecycleOwner = LocalLifecycleOwner.current
    val playerConnection = LocalPlayerConnection.current
    val code = roomSession.code.value
    val isHost = roomSession.isHost.value

    LaunchedEffect(code, isHost, token) {
        val c = code ?: return@LaunchedEffect
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            var lastRequested = ""
            while (true) {
                if (isHost) {
                    val metadata = playerConnection?.mediaMetadata?.value
                    if (metadata != null && YT_ID.matches(metadata.id)) {
                        val current = ListenState(
                            videoId = metadata.id,
                            title = metadata.title,
                            artist = metadata.artists.joinToString(", ") { it.name },
                            thumb = metadata.thumbnailUrl.orEmpty(),
                            positionMs = playerConnection.player.currentPosition.coerceAtLeast(0),
                            durationMs = playerConnection.player.duration.coerceAtLeast(0),
                            playing = playerConnection.player.playWhenReady,
                            serverTs = 0,
                        )
                        val result = CommunityApi.listenPush(token, c, current)
                        if (result.ok) roomSession.members.intValue = result.json.optInt("members", roomSession.members.intValue)
                        roomSession.remote.value = current
                    }
                } else {
                    val result = CommunityApi.listenGet(token, c)
                    if (!result.ok) {
                        if (result.code == "bad_response" || result.error.contains("ditutup")) {
                            roomSession.code.value = null
                            roomSession.isHost.value = false
                            roomSession.remote.value = null
                            return@repeatOnLifecycle
                        }
                    } else {
                        val remote = parseListenState(result.json.optJSONObject("state"))
                        val serverNow = result.json.optLong("serverTs")
                        roomSession.members.intValue = result.json.optInt("members", roomSession.members.intValue)
                        roomSession.hostName.value = result.json.optString("hostName")
                        roomSession.remote.value = remote
                        val pc = playerConnection
                        if (remote != null && remote.videoId.isNotBlank() && pc != null) {
                            if (pc.mediaMetadata.value?.id != remote.videoId) {
                                if (lastRequested != remote.videoId) {
                                    lastRequested = remote.videoId
                                    pc.playQueue(YouTubeQueue(WatchEndpoint(videoId = remote.videoId), null))
                                }
                            } else {
                                val expected = remote.positionMs + if (remote.playing) (serverNow - remote.serverTs).coerceAtLeast(0) else 0L
                                if (abs(pc.player.currentPosition - expected) > 3500) pc.player.seekTo(expected)
                                if (pc.player.playWhenReady != remote.playing) pc.player.playWhenReady = remote.playing
                            }
                        }
                    }
                }
                delay(if (isHost) 2500 else 2000)
            }
        }
    }
}

@Composable
fun ListenPanel(state: CommunityState, roomSession: ListenRoomSession, onOpenListenTogether: () -> Unit = {}) {
    val token = state.token ?: return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val playerConnection = LocalPlayerConnection.current
    val insets = LocalPlayerAwareWindowInsets.current

    var code by roomSession.code
    var isHost by roomSession.isHost
    var members by roomSession.members
    var hostName by roomSession.hostName
    var remote by roomSession.remote
    var joinInput by roomSession.joinInput
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun joinRoom(c: String) {
        scope.launch {
            busy = true; error = null
            val r = CommunityApi.listenJoin(token, c.uppercase().trim())
            busy = false
            if (r.ok) {
                code = c.uppercase().trim(); isHost = false
                members = r.json.optInt("members", 1); hostName = r.json.optString("hostName")
                remote = parseListenState(r.json.optJSONObject("state"))
            } else error = r.error
        }
    }

    // Kode dari deep link
    val pending by CommunityDeepLink.pendingCode.collectAsState()
    LaunchedEffect(pending) {
        val p = pending
        if (!p.isNullOrBlank() && code == null) { CommunityDeepLink.pendingCode.value = null; joinInput = p; joinRoom(p) }
    }

    fun currentState(): ListenState? {
        val pc = playerConnection ?: return null
        val m = pc.mediaMetadata.value ?: return null
        if (!YT_ID.matches(m.id)) return null
        return ListenState(
            videoId = m.id, title = m.title, artist = m.artists.joinToString(", ") { it.name }, thumb = m.thumbnailUrl.orEmpty(),
            positionMs = pc.player.currentPosition.coerceAtLeast(0), durationMs = pc.player.duration.coerceAtLeast(0),
            playing = pc.player.playWhenReady, serverTs = 0,
        )
    }

    fun shareText(c: String) =
        "Dengarkan musik bareng aku di Sanzxcy Music! Buka tab Komunitas → Dengar bersama dan masukkan kode: $c\nAtau buka link: $JOIN_BASE$c"

    Column(
        Modifier.fillMaxSize().windowInsetsPadding(insets.only(WindowInsetsSides.Bottom)).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PublicListenRoomsSection(username = state.me?.username.orEmpty(), onOpenListenTogether = onOpenListenTogether)
        val c = code
        if (c == null) {
            GlassCard {
                Text("Buat ruangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    stringResource(R.string.community_listen_room_create_hint),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(
                    enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp),
                    onClick = {
                        val s = currentState()
                        if (s == null) { error = context.getString(R.string.community_listen_room_requires_track); return@Button }
                        scope.launch {
                            busy = true; error = null
                            val r = CommunityApi.listenCreate(token, s)
                            busy = false
                            if (r.ok) { code = r.json.getString("code"); isHost = true; members = 1; remote = s } else error = r.error
                        }
                    },
                ) { Text("Buat ruangan") }
                OutlinedButton(
                    onClick = onOpenListenTogether,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                ) { Text("Buat room publik / privat") }
            }
            GlassCard {
                Text("Gabung ruangan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = joinInput, onValueChange = { joinInput = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(6) },
                    label = { Text("Kode (6 karakter)") }, singleLine = true, shape = RoundedCornerShape(18.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(enabled = !busy && joinInput.length == 6, onClick = { joinRoom(joinInput) }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("Gabung") }
            }
        } else {
            GlassCard {
                Text(if (isHost) "Kamu host ruangan ini" else "Terhubung ke ruangan ${hostName.ifBlank { "host" }}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(c, fontSize = 40.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 6.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text("$members pendengar", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("kode", c))
                    }, modifier = Modifier.weight(1f).height(46.dp)) { Text("Salin kode") }
                    Button(onClick = {
                        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, shareText(c)) }, "Bagikan ke"))
                    }, modifier = Modifier.weight(1f).height(46.dp)) { Text("Bagikan") }
                }
            }
            remote?.takeIf { it.videoId.isNotBlank() }?.let { s ->
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(model = s.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)))
                        Column(Modifier.padding(start = 12.dp)) {
                            Text("Sedang diputar", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text(s.title, fontWeight = FontWeight.SemiBold, maxLines = 2)
                            Text(s.artist, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
            if (isHost && currentState() == null) {
                Text(stringResource(R.string.community_listen_room_host_hint), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(
                onClick = { scope.launch { CommunityApi.listenLeave(token, c); code = null; isHost = false; remote = null } },
                modifier = Modifier.fillMaxWidth().height(50.dp),
            ) { Text(if (isHost) "Tutup ruangan" else "Keluar", color = MaterialTheme.colorScheme.error) }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PublicListenRoomsSection(username: String, onOpenListenTogether: () -> Unit) {
    val manager = LocalListenTogetherManager.current
    val scope = rememberCoroutineScope()
    var rooms by remember { mutableStateOf<List<PublicListenRoom>>(emptyList()) }
    var hasLoadedRooms by remember { mutableStateOf(false) }
    var loadingRooms by remember { mutableStateOf(false) }
    var roomsError by remember { mutableStateOf<String?>(null) }
    var joiningCode by remember { mutableStateOf<String?>(null) }
    var joinError by remember { mutableStateOf<String?>(null) }

    val connectionState = manager?.connectionState?.collectAsStateWithLifecycle()?.value ?: ConnectionState.DISCONNECTED
    val roomState = manager?.roomState?.collectAsStateWithLifecycle()?.value

    suspend fun refreshRooms() {
        loadingRooms = true
        roomsError = null
        val result = CommunityApi.listenPublicRooms()
        if (result.ok) {
            val array = result.json.optJSONArray("rooms")
            if (array == null) {
                roomsError = "Daftar ruangan publik tidak valid. Coba muat ulang."
            } else {
                rooms = (0 until array.length()).mapNotNull { index ->
                    array.optJSONObject(index)?.let { room ->
                        val code = room.optString("code").trim()
                        if (code.isBlank()) null else PublicListenRoom(
                            code = code,
                            hostName = room.optString("hostName", "Host").ifBlank { "Host" },
                            members = room.optInt("members", 1),
                            createdAt = room.optLong("createdAt"),
                        )
                    }
                }
                hasLoadedRooms = true
            }
        } else {
            roomsError = result.error.ifBlank { "Tidak dapat memuat ruangan publik. Periksa koneksi lalu coba lagi." }
        }
        loadingRooms = false
    }

    LaunchedEffect(Unit) { refreshRooms() }
    LaunchedEffect(manager) {
        manager?.events?.collect { event ->
            when (event) {
                is ListenTogetherEvent.JoinApproved,
                is ListenTogetherEvent.Reconnected -> {
                    joiningCode = null
                    joinError = null
                }
                is ListenTogetherEvent.JoinRejected -> {
                    joiningCode = null
                    joinError = event.reason.ifBlank { "Permintaan bergabung ditolak oleh host." }
                }
                is ListenTogetherEvent.ConnectionError -> {
                    if (joiningCode != null) {
                        joiningCode = null
                        joinError = event.error.ifBlank { "Koneksi Listen Together gagal. Coba bergabung lagi." }
                    }
                }
                else -> Unit
            }
        }
    }
    LaunchedEffect(roomState) {
        if (roomState != null) joiningCode = null
    }

    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Ruangan publik", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "Temukan sesi Listen Together publik yang sedang tersedia.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(enabled = !loadingRooms, onClick = { scope.launch { refreshRooms() } }) {
                Text("Muat ulang")
            }
        }

        if (loadingRooms && !hasLoadedRooms) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                Text("Memuat ruangan publik…", modifier = Modifier.padding(start = 10.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        roomsError?.let { message ->
            Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            if (!loadingRooms) OutlinedButton(onClick = { scope.launch { refreshRooms() } }, modifier = Modifier.fillMaxWidth()) {
                Text("Coba lagi")
            }
        }
        if (hasLoadedRooms && rooms.isEmpty() && roomsError == null && !loadingRooms) {
            Text("Belum ada ruangan publik yang tersedia.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (loadingRooms && hasLoadedRooms) {
            Text("Memperbarui daftar…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (roomState != null) {
            val activeRoom = roomState
            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kamu sudah bergabung", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    Text(
                        "Ruang ${activeRoom.roomCode} · ${if (manager?.isHost == true) "Host" else "Pendengar"} · ${activeRoom.usersList.count { it.isConnected }} terhubung",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenListenTogether, modifier = Modifier.weight(1f)) {
                            Text("Kontrol lengkap")
                        }
                        OutlinedButton(onClick = { manager?.leaveRoom(); joiningCode = null }, modifier = Modifier.weight(1f)) {
                            Text("Keluar")
                        }
                    }
                }
            }
        } else if (joiningCode != null) {
            Text(
                "Menghubungkan ke ruangan $joiningCode…${if (connectionState == ConnectionState.CONNECTING || connectionState == ConnectionState.RECONNECTING) " Menyiapkan koneksi." else ""}",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodySmall,
            )
        }

        joinError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

        rooms.forEach { room ->
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHighest, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(room.hostName, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text("${room.members} pendengar · Kode ${room.code}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        enabled = manager != null && username.isNotBlank() && roomState == null && joiningCode == null &&
                            manager.hasPersistedSession.not() && connectionState != ConnectionState.CONNECTING && connectionState != ConnectionState.RECONNECTING,
                        onClick = {
                            val listenTogetherManager = manager ?: return@Button
                            joinError = null
                            joiningCode = room.code
                            // joinRoom queues the request and opens one connection itself when needed.
                            listenTogetherManager.joinRoom(room.code, username)
                        },
                    ) {
                        Text(if (joiningCode == room.code) "Menghubungkan…" else "Gabung")
                    }
                }
            }
        }
        if (manager == null) {
            Text("Fitur Listen Together belum tersedia di perangkat ini.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        } else if (username.isBlank()) {
            Text("Nama akun komunitas belum tersedia untuk bergabung.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        } else if (roomState == null && manager.hasPersistedSession) {
            Text("Sesi Listen Together sebelumnya sedang dipulihkan; tunggu sampai status ruangan muncul sebelum bergabung ke ruangan lain.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        } else if (roomState == null && (connectionState == ConnectionState.CONNECTING || connectionState == ConnectionState.RECONNECTING)) {
            Text("Koneksi Listen Together sedang disiapkan.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun GlassCard(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = shape, modifier = Modifier.fillMaxWidth().glassBorder(shape, LocalLiquidGlass.current)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}
