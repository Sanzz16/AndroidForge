package com.metrolist.music.community

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.metrolist.music.MainActivity
import com.sanzxcy.music.com.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object GlobalNotificationScheduler {
    private const val ACTION_POLL = "com.sanzxcy.music.action.POLL_GLOBAL_NOTIFICATIONS"
    private const val REQUEST_CODE = 1945
    private const val INTERVAL_MS = 15 * 60 * 1000L

    fun schedule(context: Context) {
        val alarm = context.getSystemService(AlarmManager::class.java) ?: return
        val intent = Intent(context, GlobalNotificationReceiver::class.java).setAction(ACTION_POLL)
        val pending = PendingIntent.getBroadcast(context, REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 30_000L, INTERVAL_MS, pending)
    }

    fun action(): String = ACTION_POLL
}

class GlobalNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            GlobalNotificationScheduler.schedule(context)
            return
        }
        if (intent?.action != GlobalNotificationScheduler.action()) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { poll(context.applicationContext) } finally { pending.finish() }
        }
    }

    private suspend fun poll(context: Context) {
        val status = CommunityApi.appStatus() ?: return
        val prefs = context.getSharedPreferences("global_notifications", Context.MODE_PRIVATE)
        val last = prefs.getLong("last_created_at", 0L)
        if (last == 0L) {
            status.globalNotifications.maxOfOrNull { it.createdAt }?.let { prefs.edit().putLong("last_created_at", it).apply() }
            return
        }
        val fresh = status.globalNotifications.filter { it.createdAt > last }.sortedBy { it.createdAt }
        if (fresh.isEmpty()) return
        ensureChannel(context)
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            val manager = NotificationManagerCompat.from(context)
            fresh.forEach { item ->
                val open = PendingIntent.getActivity(context, item.id.hashCode(), Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_notification)
                    .setContentTitle(item.title.ifBlank { "Sanzxcy Music" })
                    .setContentText(item.text)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(item.text))
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .setContentIntent(open)
                    .build()
                manager.notify(item.id.hashCode(), notification)
            }
        }
        prefs.edit().putLong("last_created_at", fresh.maxOf { it.createdAt }).apply()
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Notifikasi Global", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "Pengumuman penting dari Sanzxcy Music" },
            )
        }
    }

    companion object { private const val CHANNEL_ID = "global_notifications" }
}
