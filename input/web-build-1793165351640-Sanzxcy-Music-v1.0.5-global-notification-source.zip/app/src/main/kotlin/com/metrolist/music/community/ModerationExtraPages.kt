package com.metrolist.music.community

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.json.JSONObject

enum class ModerationSection(val label: String) {
    BOT("Bot"), IP("Keamanan IP"), MAINTENANCE("Maintenance"), UPDATE("Update aplikasi"), CHANGELOG("Changelog"),
}

@Composable
fun ModerationNavbar(selected: ModerationSection, onSelect: (ModerationSection) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ModerationSection.entries.forEach { section ->
            if (section == selected) Button(onClick = { onSelect(section) }, content = { Text(section.label) })
            else OutlinedButton(onClick = { onSelect(section) }, content = { Text(section.label) })
        }
    }
}

@Composable
fun ModerationExtraPages(section: ModerationSection, token: String, onAuthFailure: (ApiResult) -> Unit) {
    when (section) {
        ModerationSection.IP -> IpAdminPage(token, onAuthFailure)
        ModerationSection.MAINTENANCE -> MaintenanceAdminPage(token, onAuthFailure)
        ModerationSection.UPDATE -> UpdateAdminPage(token, onAuthFailure)
        ModerationSection.CHANGELOG -> ChangelogAdminPage(token, onAuthFailure)
        ModerationSection.BOT -> Unit
    }
}

@Composable
private fun AdminCard(title: String, description: String? = null, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            description?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            content()
        }
    }
}

@Composable
private fun IpAdminPage(token: String, onAuthFailure: (ApiResult) -> Unit) {
    val scope = rememberCoroutineScope(); var ips by remember { mutableStateOf<List<String>>(emptyList()) }; var input by remember { mutableStateOf("") }; var message by remember { mutableStateOf("") }; var loading by remember { mutableStateOf(true) }
    fun reload() { scope.launch { loading = true; val r = CommunityApi.ownerRead(token, "ip.list"); loading = false; if (r.ok) ips = r.json.optJSONArray("ips")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList() else { message = r.error; onAuthFailure(r) } } }
    LaunchedEffect(Unit) { reload() }
    AdminCard("Keamanan IP", "Blokir atau buka blokir alamat IP komunitas.") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(input, { input = it }, Modifier.weight(1f), singleLine = true, label = { Text("Alamat IP") }); Button(onClick = { val ip = input.trim(); if (ip.isNotBlank()) scope.launch { val r = CommunityApi.ownerWrite(token, "ip.ban", JSONObject().put("ip", ip)); message = if (r.ok) "IP diblokir." else r.error; reload() } }) { Text("Blokir") } }
        TextButton(onClick = ::reload) { Text("Muat ulang") }; if (loading) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        ips.forEach { ip -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(ip, Modifier.weight(1f)); TextButton(onClick = { scope.launch { val r = CommunityApi.ownerWrite(token, "ip.unban", JSONObject().put("ip", ip)); message = if (r.ok) "Blokir IP dibuka." else r.error; reload() } }) { Text("Buka blokir") } } }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun MaintenanceAdminPage(token: String, onAuthFailure: (ApiResult) -> Unit) {
    val scope = rememberCoroutineScope(); var enabled by remember { mutableStateOf(false) }; var message by remember { mutableStateOf("") }; var eta by remember { mutableStateOf("") }; var notice by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { val r = CommunityApi.ownerRead(token, "status.get"); if (r.ok) { val m = r.json.optJSONObject("status")?.optJSONObject("maintenance"); enabled = m?.optBoolean("enabled") ?: false; message = m?.optString("message").orEmpty(); eta = m?.optString("eta").orEmpty() } else onAuthFailure(r) }
    AdminCard("Maintenance", "Atur pemberitahuan pemeliharaan aplikasi.") {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Aktifkan mode maintenance", Modifier.weight(1f)); Switch(enabled, { enabled = it }) }
        OutlinedTextField(message, { message = it.take(800) }, Modifier.fillMaxWidth(), minLines = 3, label = { Text("Deskripsi") })
        OutlinedTextField(eta, { eta = it.take(120) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Perkiraan selesai") })
        Button(onClick = { scope.launch { val r = CommunityApi.ownerWrite(token, "maintenance.set", JSONObject().put("enabled", enabled).put("message", message).put("eta", eta)); notice = if (r.ok) "Pengaturan maintenance disimpan." else r.error; if (!r.ok) onAuthFailure(r) } }) { Text("Simpan") }
        if (notice.isNotBlank()) Text(notice, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun UpdateAdminPage(token: String, onAuthFailure: (ApiResult) -> Unit) {
    val scope = rememberCoroutineScope(); var enabled by remember { mutableStateOf(false) }; var version by remember { mutableStateOf("") }; var code by remember { mutableStateOf("") }; var message by remember { mutableStateOf("") }; var url by remember { mutableStateOf("") }; var notice by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { val r = CommunityApi.ownerRead(token, "status.get"); if (r.ok) { val u = r.json.optJSONObject("status")?.optJSONObject("update"); enabled = u?.optBoolean("enabled") ?: false; version = u?.optString("versionName").orEmpty(); code = u?.optInt("versionCode", 0)?.toString().orEmpty(); message = u?.optString("message").orEmpty(); url = u?.optString("downloadUrl").orEmpty() } else onAuthFailure(r) }
    AdminCard("Update aplikasi", "Kelola notifikasi versi terbaru dan link APK.") {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Tampilkan notifikasi update", Modifier.weight(1f)); Switch(enabled, { enabled = it }) }
        OutlinedTextField(version, { version = it.take(30) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nama versi") })
        OutlinedTextField(code, { code = it.filter(Char::isDigit).take(8) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Version code") })
        OutlinedTextField(message, { message = it.take(1500) }, Modifier.fillMaxWidth(), minLines = 3, label = { Text("Deskripsi update") })
        OutlinedTextField(url, { url = it.take(500) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Link APK HTTPS") })
        Button(onClick = { scope.launch { val r = CommunityApi.ownerWrite(token, "update.set", JSONObject().put("enabled", enabled).put("versionName", version).put("versionCode", code.toIntOrNull() ?: 0).put("message", message).put("downloadUrl", url)); notice = if (r.ok) "Pengaturan update disimpan." else r.error; if (!r.ok) onAuthFailure(r) } }) { Text("Simpan") }
        if (notice.isNotBlank()) Text(notice, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun ChangelogAdminPage(token: String, onAuthFailure: (ApiResult) -> Unit) {
    val scope = rememberCoroutineScope(); var markdown by remember { mutableStateOf("") }; var notice by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { val r = CommunityApi.ownerRead(token, "status.get"); if (r.ok) markdown = r.json.optJSONObject("changelog")?.optString("md").orEmpty() else onAuthFailure(r) }
    AdminCard("Changelog", "Tulis catatan rilis dalam format Markdown.") {
        OutlinedTextField(markdown, { markdown = it.take(60000) }, Modifier.fillMaxWidth(), minLines = 12, label = { Text("Isi changelog") })
        Button(onClick = { scope.launch { val r = CommunityApi.ownerWrite(token, "changelog.set", JSONObject().put("md", markdown)); notice = if (r.ok) "Changelog disimpan." else r.error; if (!r.ok) onAuthFailure(r) } }) { Text("Simpan changelog") }
        if (notice.isNotBlank()) Text(notice, color = MaterialTheme.colorScheme.primary)
    }
}
