Build: BUILD SUCCESSFUL
APK Signature Scheme v2: true
Server tests: 46 passed, 0 failed

SHA-256 APK:
e15fd3695928560a60b84e8261f8c24f7236711b89878e52b06110aedbfaef65

File keystore      : Sanzxcy-release.keystore
Tipe keystore      : PKCS12
Password keystore  : Sanzxmzz_1945
Alias              : sanzxcy-release
Kata sandi alias   : Sanzxmzz_1945
Algoritma          : RSA 4096-bit
